#pragma once
const int invalidDistance = 999999999;