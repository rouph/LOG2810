#include "graph.h"
#include "Program.h"
#include <iostream>
#include <string>

int main()
{
	Program ourProgram;
	ourProgram.StartProgram();
	return 0;
}